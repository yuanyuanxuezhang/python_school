import time
scale=10
z = "Starting"
print(z,end=' ')
for i in range(scale+1):
    a='*'
    print(a,end="")
    time.sleep(0.3)
print("Done!")