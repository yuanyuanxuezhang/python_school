# -*- coding: utf-8 -*-
# 时          间 : 2021/10/16 14:39
# 高贵的高级工程师 : 元元学长
def text():
    a = 'python'
    b = 'php'
    c = 'java'
    return a,b,c
    return a
x = text()
print(x)
print(x[0])