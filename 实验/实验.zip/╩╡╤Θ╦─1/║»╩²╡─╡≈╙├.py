# -*- coding: utf-8 -*-
# 时          间 : 2021/10/16 14:32
# 高贵的高级工程师 : 元元学长
def add(x):
    a = x+x
    return a
def jian(y):
    a = add(y) -1
    return a

b = jian(4)
print(b)