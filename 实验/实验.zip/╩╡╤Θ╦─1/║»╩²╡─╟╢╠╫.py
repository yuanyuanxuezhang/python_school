# -*- coding: utf-8 -*-
# 时          间 : 2021/10/16 14:35
# 高贵的高级工程师 : 元元学长
def hhh():
    class_name = '''python
    php
    java'''
    def dayin():
        print(class_name)
    return dayin()

hhh()