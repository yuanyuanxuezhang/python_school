from PIL import Image
from PIL import ImageFilter
from PIL import ImageEnhance
im = Image.open('1.png')
om = im.filter(ImageFilter.CONTOUR)
om.save('1.png')
