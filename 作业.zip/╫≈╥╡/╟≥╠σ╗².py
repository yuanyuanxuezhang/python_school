#calvolumesph.py
r=eval(input())
#********* Begin *********#
v=(4/3)*3.14159*r**3
print(round(v,2))

#********* End *********#